//JavaScript

var streetNumber = 19396; // My house street number
var streetName = "liberty"; // My house street name
var favoriteColorBlue = true; // My favorite color blue

console.log(streetNumber);
console.log(streetName);
console.log(favoriteColorBlue);

//Flavio Cassini
//Student# 0004664025
//08/06/2015
//Instructor Lee Lewis
//Program: Web Development & Design